import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Heart } from "lucide-react"

export function CTA() {
  return (
    <section id="contribuir" className="py-20 bg-gradient-to-br from-primary/20 to-background">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6">
            Faça Parte da Nossa Família
          </h2>
          <p className="text-muted-foreground text-lg mb-8">
            Seja bem-vindo a IPAD Igreja. Aqui você encontrará um lugar de acolhimento, amor e crescimento espiritual. Venha nos visitar!
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90">
              <Link href="#contato">Entre em Contato</Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="border-foreground/20 hover:border-primary hover:text-primary">
              <Link href="/doacoes" className="flex items-center gap-2">
                <Heart className="h-4 w-4" />
                Contribuir
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
