import { Clock, MapPin } from "lucide-react"

const scheduleItems = [
  { 
    day: "Domingo", 
    activities: [
      { name: "Culto da Família", time: "19:00 - 21:00" }
    ]
  },
  { 
    day: "Terça-feira", 
    activities: [
      { name: "Consagração", time: "08:00 - 09:00" },
      { name: "Estudo Bíblico", time: "19:30 - 21:00" }
    ]
  },
  { 
    day: "Quinta-feira", 
    activities: [
      { name: "Culto de Campanha", time: "19:30 - 21:00" }
    ]
  },
  { 
    day: "Sexta-feira", 
    activities: [
      { name: "Consagração", time: "08:00 - 09:00" },
      { name: "Oração", time: "19:30 - 20:15" }
    ]
  },
]

export function Schedule() {
  return (
    <section id="cultos" className="py-20 bg-secondary">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Horários de Culto
          </h2>
          <p className="text-muted-foreground text-lg">
            Junte-se a nós em nossos encontros semanais
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 max-w-5xl mx-auto mb-8">
          {scheduleItems.map((item) => (
            <div
              key={item.day}
              className="bg-card rounded-xl p-6 text-center border border-primary/20 hover:border-primary/50 transition-colors"
            >
              <div className="w-14 h-14 mx-auto mb-4 rounded-full border-2 border-primary flex items-center justify-center">
                <Clock className="h-5 w-5 text-primary" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-3">{item.day}</h3>
              <div className="space-y-2">
                {item.activities.map((activity) => (
                  <div key={activity.name} className="text-sm">
                    <p className="text-foreground font-medium">{activity.name}</p>
                    <p className="text-muted-foreground text-xs">{activity.time}</p>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="text-center">
          <div className="inline-flex items-center gap-2 text-muted-foreground">
            <MapPin className="h-5 w-5 text-primary" />
            <span>QS 617 Conjunto R, Lote 01 - Samambaia Norte, Brasília - DF</span>
          </div>
        </div>
      </div>
    </section>
  )
}
