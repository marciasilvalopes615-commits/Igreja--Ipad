"use client"

import Link from "next/link"
import { MessageCircle } from "lucide-react"

export function WhatsAppButton() {
  const phoneNumber = "5561994442012"
  const message = encodeURIComponent("Olá! Gostaria de mais informações sobre a IPAD Igreja.")
  const whatsappUrl = `https://wa.me/${phoneNumber}?text=${message}`

  return (
    <Link
      href={whatsappUrl}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-50 w-14 h-14 bg-[#25D366] hover:bg-[#20BA5C] rounded-full flex items-center justify-center shadow-lg transition-all hover:scale-110"
      aria-label="Contato pelo WhatsApp"
    >
      <MessageCircle className="h-7 w-7 text-white fill-white" />
    </Link>
  )
}
