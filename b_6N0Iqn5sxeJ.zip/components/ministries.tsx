import { Music, Users, BookOpen, Heart } from "lucide-react"

const ministries = [
  {
    icon: Music,
    title: "Louvor e Adoração",
    description: "Ministério de música que conduz a igreja em momentos de adoração",
  },
  {
    icon: Users,
    title: "Jovens e Adolescentes",
    description: "Conectando a nova geração com Deus e uns com os outros",
  },
  {
    icon: BookOpen,
    title: "Escola Bíblica",
    description: "Ensino sistemático da Palavra de Deus para todas as idades",
  },
  {
    icon: Heart,
    title: "Ação Social",
    description: "Levando amor e esperança para comunidades carentes",
  },
]

export function Ministries() {
  return (
    <section id="ministerios" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Nossos Ministérios
          </h2>
          <p className="text-muted-foreground text-lg">
            Diversos ministérios para servir e crescer juntos
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 max-w-5xl mx-auto">
          {ministries.map((ministry) => (
            <div
              key={ministry.title}
              className="bg-card rounded-xl p-6 text-center border border-border hover:border-primary/30 transition-colors"
            >
              <div className="w-16 h-16 mx-auto mb-4 rounded-xl bg-primary/10 flex items-center justify-center">
                <ministry.icon className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">{ministry.title}</h3>
              <p className="text-muted-foreground text-sm">{ministry.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
