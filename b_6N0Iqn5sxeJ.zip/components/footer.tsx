import Link from "next/link"
import { Church, Instagram, MapPin, Phone, Clock } from "lucide-react"

const scheduleItems = [
  { day: "Domingo", time: "19:00 - 21:00" },
  { day: "Terça-feira", time: "08:00 - 09:00" },
  { day: "Quinta-feira", time: "19:30 - 21:00" },
  { day: "Sexta-feira", time: "19:30 - 20:15" },
]

export function Footer() {
  return (
    <footer id="contato" className="bg-card border-t border-border">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <Link href="/" className="flex items-center gap-2 text-primary font-bold text-lg mb-4">
              <Church className="h-6 w-6" />
              <span>IPAD Igreja</span>
            </Link>
            <p className="text-muted-foreground text-sm mb-4">
              Igreja Pentecostal Aliança com Deus - Um lugar de fé, amor e comunhão onde vidas são transformadas pelo poder de Deus.
            </p>
            <div className="flex gap-3">
              <Link
                href="https://www.instagram.com/ipad.igreja/"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center text-muted-foreground hover:text-primary hover:bg-primary/10 transition-colors"
                aria-label="Instagram"
              >
                <Instagram className="h-5 w-5" />
              </Link>
            </div>
          </div>

          <div>
            <h3 className="font-semibold text-foreground mb-4">Horários de Culto</h3>
            <ul className="space-y-3">
              {scheduleItems.map((item) => (
                <li key={item.day} className="flex items-start gap-2">
                  <Clock className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                  <div>
                    <p className="text-sm text-foreground">{item.day}</p>
                    <p className="text-sm text-muted-foreground">{item.time}</p>
                  </div>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-foreground mb-4">Contato</h3>
            <ul className="space-y-3">
              <li className="flex items-start gap-2">
                <MapPin className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                <span className="text-sm text-muted-foreground">
                  QS 617 Conjunto R, Lote 01 - Samambaia Norte, Brasília - DF
                </span>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="h-4 w-4 text-primary shrink-0" />
                <span className="text-sm text-muted-foreground">(61) 99444-2012</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-border mt-8 pt-8 text-center">
          <p className="text-sm text-muted-foreground">
            © 2026 IPAD Igreja - Igreja Pentecostal Aliança com Deus. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>
  )
}
