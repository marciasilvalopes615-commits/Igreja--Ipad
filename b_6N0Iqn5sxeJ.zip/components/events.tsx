import { Calendar, Clock } from "lucide-react"

const events = [
  {
    date: "Todo Domingo",
    title: "Culto da Família",
    description: "Venha celebrar e adorar ao Senhor conosco",
    time: "19:00",
  },
  {
    date: "Toda Terça",
    title: "Estudo Bíblico",
    description: "Aprofunde seu conhecimento da Palavra",
    time: "19:30",
  },
  {
    date: "Toda Quinta",
    title: "Culto de Campanha",
    description: "Culto de oração e intercessão",
    time: "19:30",
  },
]

export function Events() {
  return (
    <section id="eventos" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Próximos Eventos
          </h2>
          <p className="text-muted-foreground text-lg">
            Confira nossa programação e participe das nossas atividades
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto mb-8">
          {events.map((event) => (
            <div
              key={event.title}
              className="bg-card rounded-xl p-6 border border-border hover:border-primary/30 transition-colors"
            >
              <div className="flex items-center gap-2 text-primary mb-3">
                <Calendar className="h-4 w-4" />
                <span className="text-sm font-medium">{event.date}</span>
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">{event.title}</h3>
              <p className="text-muted-foreground text-sm mb-4">{event.description}</p>
              <div className="flex items-center gap-2 text-muted-foreground text-sm">
                <Clock className="h-4 w-4" />
                <span>{event.time}</span>
              </div>
            </div>
          ))}
        </div>

        </div>
    </section>
  )
}
