"use client"

import Image from "next/image"
import { useState } from "react"
import { X, ChevronLeft, ChevronRight } from "lucide-react"

const galleryImages = [
  { src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/img10.jpg-RO9KsB53ayLxauFO7oCR6PirOLf57B.jpg", alt: "Coral da igreja" },
  { src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/img7.jpg-R2oJCHSCyqUog4ezM97Fn02bo2rZgR.jpg", alt: "Congregação em culto" },
  { src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/ima11.jpg-cGZXk3CQv3iio7wJgpkaGEK45bc54g.webp", alt: "Fachada da igreja" },
  { src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/img1.jpg.jfif-qgkMYbL4haWfhSLSOuIEKuuMIMvnaE.jpeg", alt: "Culto de celebração" },
  { src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/img4.jpg-5yqsfPwlU2Uu9DOY6QyQ3ksLCMxXbg.jpg", alt: "Transmissão ao vivo" },
  { src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/img3.jpg-TUcQ5e0ZWck8GHrrPCj4e891uu3lF7.jpg", alt: "Igreja à noite" },
  { src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/img9.jpg-fnzVCgAqluHVv64jiFUbMwWwWaDim8.jpg", alt: "28º Aniversário" },
  { src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/img5.jpg-dCavYHPe9j5hdlv38u9wvxh0V8I3Z1.jpg", alt: "Grupo de louvor" },
  { src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/img8.jpg-bh2N0t1aEv6Wp0b5JCVe7LCG1ylUm8.jpg", alt: "Culto de oração" },
  { src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/img6.jpg-wGEQrp9dHw3vIoKf27S3tNfouyeSiZ.jpg", alt: "Jovens em adoração" },
  { src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/img2.jpg-Onk33fceeLkqhKBebGoqbosxrUcavY.jpg", alt: "Ministério de jovens" },
]

export function Gallery() {
  const [selectedImage, setSelectedImage] = useState<number | null>(null)

  const openLightbox = (index: number) => setSelectedImage(index)
  const closeLightbox = () => setSelectedImage(null)
  const goToPrevious = () => setSelectedImage((prev) => (prev !== null && prev > 0 ? prev - 1 : galleryImages.length - 1))
  const goToNext = () => setSelectedImage((prev) => (prev !== null && prev < galleryImages.length - 1 ? prev + 1 : 0))

  return (
    <section id="galeria" className="py-20 bg-secondary">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Galeria de Fotos
          </h2>
          <p className="text-muted-foreground text-lg">
            Momentos especiais da nossa comunidade
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 max-w-6xl mx-auto">
          {galleryImages.map((image, index) => (
            <button
              key={image.alt}
              onClick={() => openLightbox(index)}
              className="relative aspect-square rounded-xl overflow-hidden group cursor-pointer"
            >
              <Image
                src={image.src}
                alt={image.alt}
                fill
                className="object-cover transition-transform duration-300 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <span className="text-white font-medium text-sm text-center px-2">{image.alt}</span>
              </div>
            </button>
          ))}
        </div>

        {/* Video Section */}
        <div className="mt-12 max-w-4xl mx-auto">
          <h3 className="text-2xl font-bold text-foreground mb-6 text-center">Vídeo</h3>
          <div className="relative aspect-video rounded-xl overflow-hidden bg-black">
            <video
              controls
              className="w-full h-full"
              poster="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/img10.jpg-RO9KsB53ayLxauFO7oCR6PirOLf57B.jpg"
            >
              <source src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/video.mp4-11IgGTggK7er1vlu79etkPADw1lMcO.mp4" type="video/mp4" />
              Seu navegador não suporta a reprodução de vídeos.
            </video>
          </div>
        </div>
      </div>

      {/* Lightbox */}
      {selectedImage !== null && (
        <div className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4">
          <button
            onClick={closeLightbox}
            className="absolute top-4 right-4 text-white hover:text-primary transition-colors"
            aria-label="Fechar"
          >
            <X className="h-8 w-8" />
          </button>
          <button
            onClick={goToPrevious}
            className="absolute left-4 text-white hover:text-primary transition-colors"
            aria-label="Anterior"
          >
            <ChevronLeft className="h-10 w-10" />
          </button>
          <div className="relative max-w-4xl max-h-[80vh] w-full h-full">
            <Image
              src={galleryImages[selectedImage].src}
              alt={galleryImages[selectedImage].alt}
              fill
              className="object-contain"
            />
          </div>
          <button
            onClick={goToNext}
            className="absolute right-4 text-white hover:text-primary transition-colors"
            aria-label="Próximo"
          >
            <ChevronRight className="h-10 w-10" />
          </button>
          <p className="absolute bottom-4 text-white text-center w-full">
            {galleryImages[selectedImage].alt}
          </p>
        </div>
      )}
    </section>
  )
}
