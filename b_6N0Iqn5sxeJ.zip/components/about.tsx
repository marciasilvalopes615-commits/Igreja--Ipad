import Image from "next/image"
import { Church, Heart, Users } from "lucide-react"

export function About() {
  return (
    <section id="sobre" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Nossa História
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Uma jornada de fé que começou em um lar e se transformou em uma comunidade
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center max-w-6xl mx-auto">
          <div className="relative aspect-[4/3] rounded-2xl overflow-hidden">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-W04oAQiO2ZJvK6IXOr2QQqcGrTXQXQ.png"
              alt="Fachada da Igreja Pentecostal Aliança com Deus"
              fill
              className="object-cover"
            />
          </div>

          <div className="space-y-6">
            <div className="space-y-4 text-muted-foreground">
              <p>
                A história da <strong className="text-foreground">Igreja Pentecostal Aliança com Deus</strong> começou 
                antes mesmo de receber esse nome. Em <strong className="text-foreground">1995</strong>, tudo teve início 
                de forma simples e acolhedora: um culto no lar, realizado dentro de uma casa, guiado pela fé e pela 
                direção de Deus.
              </p>
              <p>
                Esse formato de culto familiar permaneceu até <strong className="text-foreground">1997</strong>, quando a 
                congregação mudou para outra casa, mas manteve a essência do culto no lar. A comunhão entre os irmãos 
                crescia, e a presença de Deus se manifestava de forma poderosa em cada reunião.
              </p>
              <p>
                Conforme a direção do Senhor, em <strong className="text-foreground">2003</strong>, Deus abriu as portas 
                para uma nova etapa: a construção de um templo próprio em um lote, onde a igreja está estabelecida até 
                hoje. O culto no lar deu lugar a um espaço dedicado à adoração, mas o espírito de família e comunhão 
                permanece vivo.
              </p>
              <p>
                Hoje, somos conhecidos como <strong className="text-foreground">IPAD - Igreja Pentecostal Aliança com Deus</strong>, 
                uma comunidade que honra suas raízes humildes e continua firme no propósito de transformar vidas através 
                do amor de Cristo.
              </p>
            </div>

            <div className="grid grid-cols-3 gap-4 pt-6">
              <div className="text-center p-4 bg-card rounded-xl">
                <Church className="h-8 w-8 text-primary mx-auto mb-2" />
                <p className="text-2xl font-bold text-foreground">1995</p>
                <p className="text-xs text-muted-foreground">Fundação</p>
              </div>
              <div className="text-center p-4 bg-card rounded-xl">
                <Heart className="h-8 w-8 text-primary mx-auto mb-2" />
                <p className="text-2xl font-bold text-foreground">30+</p>
                <p className="text-xs text-muted-foreground">Anos de história</p>
              </div>
              <div className="text-center p-4 bg-card rounded-xl">
                <Users className="h-8 w-8 text-primary mx-auto mb-2" />
                <p className="text-2xl font-bold text-foreground">2003</p>
                <p className="text-xs text-muted-foreground">Templo próprio</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
