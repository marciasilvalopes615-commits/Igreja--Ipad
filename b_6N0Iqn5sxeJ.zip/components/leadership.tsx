import Image from "next/image"

export function Leadership() {
  return (
    <section id="lideranca" className="py-20 bg-card">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Nossa Liderança
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Servindo a Deus e à comunidade com amor e dedicação
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="bg-secondary rounded-2xl overflow-hidden border border-border">
            <div className="grid md:grid-cols-2 gap-0">
              <div className="relative aspect-square md:aspect-auto">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-w6pBvCYmtqyKLwtGiCc299LgDaRhUS.png"
                  alt="Pastora Maria Eulalia e Obreiro Irmão Walter"
                  fill
                  className="object-cover"
                />
              </div>
              <div className="p-8 flex flex-col justify-center">
                <div className="space-y-6">
                  <div>
                    <span className="text-primary text-sm font-semibold uppercase tracking-wider">
                      Pastora Líder
                    </span>
                    <h3 className="text-2xl font-bold text-foreground mt-1">
                      Maria Eulalia
                    </h3>
                    <p className="text-muted-foreground mt-2">
                      Com amor e dedicação, lidera nossa congregação na fé e no serviço ao Senhor, 
                      guiando vidas no caminho da salvação desde os primeiros dias da igreja.
                    </p>
                  </div>
                  
                  <div className="border-t border-border pt-6">
                    <span className="text-primary text-sm font-semibold uppercase tracking-wider">
                      Obreiro
                    </span>
                    <h3 className="text-2xl font-bold text-foreground mt-1">
                      Irmão Walter
                    </h3>
                    <p className="text-muted-foreground mt-2">
                      Fiel companheiro e marido da Pastora Maria Eulalia, serve ao lado dela 
                      com dedicação incansável, apoiando a obra de Deus em nossa comunidade.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="text-center mt-8">
            <p className="text-muted-foreground italic">
              &ldquo;E tudo quanto fizerdes, fazei-o de todo o coração, como ao Senhor e não aos homens.&rdquo;
            </p>
            <p className="text-primary text-sm mt-2">Colossenses 3:23</p>
          </div>
        </div>
      </div>
    </section>
  )
}
