import Link from "next/link"
import { Church, ArrowLeft, Copy, CreditCard, QrCode, Smartphone } from "lucide-react"
import { Button } from "@/components/ui/button"

export const metadata = {
  title: "Doações - IPAD Igreja",
  description: "Contribua com a obra de Deus através da Igreja Pentecostal Aliança com Deus",
}

export default function DoacoesPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="flex items-center gap-2 text-primary font-bold text-lg">
              <Church className="h-6 w-6" />
              <span>IPAD Igreja</span>
            </Link>
            <Button asChild variant="ghost" className="text-muted-foreground hover:text-foreground">
              <Link href="/" className="flex items-center gap-2">
                <ArrowLeft className="h-4 w-4" />
                Voltar
              </Link>
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12">
        <div className="max-w-3xl mx-auto">
          {/* Title */}
          <div className="text-center mb-12">
            <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Contribua com a Obra de Deus
            </h1>
            <p className="text-muted-foreground text-lg">
              Sua oferta é um ato de adoração e faz parte do sustento da obra do Senhor.
              Deus ama ao que dá com alegria.
            </p>
          </div>

          {/* Versículo */}
          <div className="bg-card rounded-2xl p-6 mb-8 border border-border text-center">
            <p className="text-foreground italic text-lg mb-2">
              {'"Cada um dê conforme determinou em seu coração, não com pesar ou por obrigação, pois Deus ama quem dá com alegria."'}
            </p>
            <p className="text-primary font-semibold">2 Coríntios 9:7</p>
          </div>

          {/* Métodos de Doação */}
          <div className="space-y-6">
            {/* PIX */}
            <div className="bg-card rounded-2xl p-6 border border-border">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                  <Smartphone className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-foreground">PIX</h2>
                  <p className="text-sm text-muted-foreground">Transferência instantânea</p>
                </div>
              </div>
              <div className="bg-secondary rounded-xl p-4 mb-4">
                <p className="text-sm text-muted-foreground mb-1">Chave PIX (CNPJ):</p>
                <div className="flex items-center justify-between gap-2">
                  <p className="text-foreground font-mono text-lg">02.380.594/0001-39</p>
                  <Button variant="outline" size="sm" className="shrink-0">
                    <Copy className="h-4 w-4 mr-2" />
                    Copiar
                  </Button>
                </div>
              </div>
              <p className="text-sm text-muted-foreground">
                Escaneie o QR Code ou utilize a chave PIX acima para realizar sua doação.
              </p>
            </div>

            {/* Transferência Bancária */}
            <div className="bg-card rounded-2xl p-6 border border-border">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                  <CreditCard className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-foreground">Transferência Bancária</h2>
                  <p className="text-sm text-muted-foreground">TED ou DOC</p>
                </div>
              </div>
              <div className="bg-secondary rounded-xl p-4 space-y-3">
                <div>
                  <p className="text-sm text-muted-foreground">Banco:</p>
                  <p className="text-foreground font-medium">CAIXA ECONÔMICA FEDERAL</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Chave PIX (CNPJ):</p>
                  <p className="text-foreground font-medium font-mono">02.380.594/0001-39</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Titular:</p>
                  <p className="text-foreground font-medium">Igreja Pentecostal Aliança com Deus</p>
                </div>
              </div>
            </div>

            {/* Presencial */}
            <div className="bg-card rounded-2xl p-6 border border-border">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                  <Church className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-foreground">Presencial</h2>
                  <p className="text-sm text-muted-foreground">Nos cultos</p>
                </div>
              </div>
              <p className="text-muted-foreground">
                Você também pode contribuir presencialmente durante nossos cultos.
              </p>
              <div className="mt-4 p-4 bg-secondary rounded-xl">
                <p className="text-sm text-foreground font-medium">Endereço:</p>
                <p className="text-sm text-muted-foreground">
                  QS 617 Conjunto R, Lote 01 - Samambaia Norte, Brasília - DF
                </p>
              </div>
            </div>
          </div>

          {/* Nota */}
          <div className="mt-8 text-center">
            <p className="text-sm text-muted-foreground">
              Em caso de dúvidas, entre em contato pelo WhatsApp: 
              <span className="text-primary font-medium"> (61) 99444-2012</span>
            </p>
          </div>

          {/* Botão Voltar */}
          <div className="mt-12 text-center">
            <Button asChild size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90">
              <Link href="/">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Voltar para o início
              </Link>
            </Button>
          </div>
        </div>
      </main>
    </div>
  )
}
