import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" });

export const metadata: Metadata = {
  title: 'IPAD Igreja - Igreja Pentecostal Aliança com Deus',
  description: 'Um lugar de fé, amor e comunhão onde vidas são transformadas pelo poder de Deus.',
  keywords: ['igreja', 'pentecostal', 'aliança com deus', 'culto', 'evangélica', 'brasília', 'samambaia'],
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="pt-BR" className="scroll-smooth">
      <body className={`${inter.variable} font-sans antialiased bg-background text-foreground`}>
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
