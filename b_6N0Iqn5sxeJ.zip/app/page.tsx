import { Header } from "@/components/header"
import { Hero } from "@/components/hero"
import { About } from "@/components/about"
import { Leadership } from "@/components/leadership"
import { Schedule } from "@/components/schedule"
import { Events } from "@/components/events"
import { Ministries } from "@/components/ministries"
import { Gallery } from "@/components/gallery"
import { CTA } from "@/components/cta"
import { Footer } from "@/components/footer"
import { WhatsAppButton } from "@/components/whatsapp-button"

export default function Home() {
  return (
    <>
      <Header />
      <main>
        <Hero />
        <About />
        <Leadership />
        <Schedule />
        <Events />
        <Ministries />
        <Gallery />
        <CTA />
      </main>
      <Footer />
      <WhatsAppButton />
    </>
  )
}
